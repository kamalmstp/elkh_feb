<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
    <link href="<?php echo e(asset('css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2>
		<i class="icon-columns"></i> Manajemen Satuan Output dan Waktu
		&ensp;&emsp;
		<button data-toggle="modal" data-target="#inputModal" class="btn btn-primary">
			<i class="icon-plus"></i>  Tambah Satuan Baru
		</button>
		<?php echo $__env->make('satuan.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</h2>
	<hr>

	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<div class="table-responsive">
		<table class="table table-bordered table-small" id="dataTable" width="100%" cellspacing="0">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Satuan</th>
		            <th>Nama</th>
		            <th>Opsi</th>
		        </tr>
		    </thead>
		    <tbody>
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $satuan_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php 
				    	$no++;				    	
				     ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($satuan->satuan); ?></td>
			            <td><?php echo e($satuan->nama); ?></td>
			            <td>
			            	<table border="0">
			            	<tr>			            		
			            		<td>		            			
			            			<button data-toggle="modal" data-target="#editModal_<?php echo e($no); ?>" class="btn btn-info btn-small" title="Edit Satuan"><i class="icon-edit"></i>
									</button>
									<?php echo $__env->make('satuan.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            		</td>
			            		<td>
			            			<form method="POST" action="<?php echo e(route('satuan_delete', $satuan->id)); ?>">
				                    	<input name="_method" type="hidden" value="DELETE">
				                      	<input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
				                      	<button type="submit" class="btn btn-small btn-danger "  title="Hapus data satuan" onclick="return confirm('Anda yakin akan menghapus data satuan?')">
				                          	<i class="icon-trash"></i>
				                      	</button>
				                    </form>    		
			            		</td>
			            	</tr>
			            	</table>		            		
			            </td>	            
			        </tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
		    </tbody>
		</table>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
	<script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
	<script src="<?php echo e(asset('js/dataTables.bootstrap4.js')); ?>"></script>
	<script src="<?php echo e(asset('js/sb-admin-datatables.min.js')); ?>"></script>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>