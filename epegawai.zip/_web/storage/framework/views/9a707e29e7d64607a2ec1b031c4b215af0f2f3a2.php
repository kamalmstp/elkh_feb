<div id="inputModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="inputModalLabel" aria-hidden="true">
		<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="inputModalLabel">Tambah SKP Baru</h3>
 	</div>
	<form action="<?php echo e(route('skp_save')); ?>" method="POST" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

	  	<div class="modal-body">
		  	<div class="row">				
				<div class="span6">											
					<label class="control-label">Tahun</label>
					<div class="controls">
						<select class="span5" name="tahun_id" autofocus required>
							<?php if( old('tahun_id') ): ?>
	                            <option value="<?php echo e(old('tahun_id')); ?>">
	                        		<?php $__currentLoopData = $thn_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if( old('tahun_id') == $thn->id): ?>
											<?php echo e($thn->tahun); ?>

										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    	
	                            </option>
	                        <?php else: ?>
	                        	<option value="">-- pilih --</option>
	                        <?php endif; ?>
							<?php $__currentLoopData = $thn_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($thn->id); ?>"><?php echo e($thn->tahun); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>											
					</div>
				</div>				
			</div>
		</div>
	  	<div class="modal-footer">
	    	<button class="btn" data-dismiss="modal" aria-hidden="true">Batal</button>
	    	<button type="submit" class="btn btn-primary">Tambah</button>
	  	</div>
  	</form>
</div>