<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('skp_list')); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-table"></i> Kegiatan SKP Tahun <?php echo e($skp->tahun->tahun); ?>

	</h2>
	<h3>
		<?php echo e($skp->user->name); ?> - <?php echo e($skp->user->jabatan); ?>

	</h3>
	<hr>

	<?php if( count($skpkeg_list) > 0 ): ?>		
		<?php $__currentLoopData = $jangka_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jangka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="<?php echo e(route('target_list', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" class="btn btn-warning" title="Lihat/Input Target" style="font-weight: bold;">
				Target <?php echo e($jangka->jangka); ?>

			</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
	<?php else: ?>
		<h2>Data Belum Diisi</h2>
	<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>