<div id="editModal_<?php echo e($no); ?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="editModalLabel_<?php echo e($no); ?>" aria-hidden="true">
		<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="editModalLabel_<?php echo e($no); ?>">Edit Pangkat & Golongan</h3>
 	</div>
	<form action="<?php echo e(route('kegiatan_update', $keg->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="_method" value="PATCH">
	  	<div class="modal-body">
		  	<div class="row">
				<div class="span6">											
					<label class="control-label">Kegiatan</label>
					<div class="controls">
						<textarea name="kegiatan" class="span4" required autofocus><?php echo e($keg->kegiatan); ?></textarea>
					</div> 
				</div> 				
			</div>
		</div>
	  	<div class="modal-footer">
	    	<button class="btn" data-dismiss="modal" aria-hidden="true">Batal</button>
	    	<button type="submit" class="btn btn-primary">Simpan</button>
	  	</div>
  	</form>
</div>