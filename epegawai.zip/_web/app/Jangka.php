<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jangka extends Model
{
    protected $table = 'jangka';

	protected $fillable = ['jangka'];
}
