@extends('_layout.base')

@section('css')
    @parent
@stop

@section('content')
    <h1>DASHBOARD</h1>
@stop

@section('js')
  @parent
@stop
