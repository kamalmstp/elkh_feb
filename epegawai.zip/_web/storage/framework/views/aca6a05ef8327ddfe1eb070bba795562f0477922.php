<div id="editModal_<?php echo e($no); ?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="editModalLabel_<?php echo e($no); ?>" aria-hidden="true">
		<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="editModalLabel_<?php echo e($no); ?>">Edit Target Kegiatan SKP</h3>
 	</div>
	<form action="<?php echo e(route('skpkegiatan_update', $skpkeg->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="_method" value="PATCH">
	  	<div class="modal-body">
		  	<div class="row">				
				<div class="span6">											
					<label class="control-label">Kegiatan</label>
					<div class="controls">
						<select class="js-example-placeholder-single span6" name="kegiatan_id" required autofocus>	
							<?php $__currentLoopData = $keg_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($keg->id); ?>" <?php if($skpkeg->kegiatan_id == $keg->id): ?> selected <?php endif; ?>>
									<?php echo e($keg->kegiatan); ?>

								</option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>					
					</div>
				</div>				
			</div>
		</div>
	  	<div class="modal-footer">
	    	<button class="btn" data-dismiss="modal" aria-hidden="true">Batal</button>
	    	<button type="submit" class="btn btn-primary">Simpan</button>
	  	</div>
  	</form>
</div>