<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('skpkegiatan_list', $skp->id)); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-screenshot"></i> 
		Target SKP <?php echo e($skp->tahun->tahun); ?> Jangka Waktu <?php echo e($jangka->jangka); ?>


		<button data-toggle="modal" data-target="#pdfModal" class="btn btn-default">
			<i class="icon-file"></i> Download PDF
		</button>
		<?php echo $__env->make('skp.target_pdf_tgl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</h2>	
	<hr>

	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>
	<?php if(Session::has('gagal')): ?>
	  <div class="alert alert-danger" role="alert"><?php echo e(Session::get('gagal')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<?php if($jangka->id == 3): ?>	
		<div class="alert alert-info" role="alert">
			Untuk Target SKP Semester 2, Nilai Kuantitas dan Waktu otomatis didapat dari Nilai Target 1 Tahun dikurang Nilai Realisasi Semester 1.
		</div>	    
	<?php endif; ?>
	
	<div class="table-responsive" style="overflow-x: auto;">
		<form action="<?php echo e(route('target_update', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" method="POST" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>		    				    	
			<input type="hidden" name="_method" value="PATCH">
		<table class="table table-bordered table-small">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Kegiatan</th>
		            <th>AK</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Kuantitas</th>
		            <th>Mutu</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Waktu</th>
		            <th>Biaya</th>		            
		        </tr>
		    </thead>
		    <?php if($status == 'yes' && $jangka->id == 1): ?>		    
		    <tbody>		    	
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $tgt_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php $no++; ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($tgt->skpkegiatan->kegiatan->kegiatan); ?></td>
			            <td>
			            	<input type="text" class="span1" name="ak[]" 
			            	value="<?php echo e($tgt->ak); ?>" oninput="angka(this);">
			            </td>
			            <td>
			            	<input type="text" class="span1" name="kuantitas[]" 
			            	value="<?php echo e($tgt->kuantitas); ?>" oninput="angka(this);" required>
			            </td>
			            <td width="8%">
							<select  name="output_id[]" style="width:100%;" required>
								<option value="">--pilih--</option>
								<?php $__currentLoopData = $output_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $output): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($output->id); ?>" <?php if($tgt->output_id == $output->id): ?> selected <?php endif; ?>>
										<?php echo e($output->nama); ?>

									</option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
			            </td>
			            <td>
			            	<input type="text" class="span1" name="mutu[]" 
			            	value="<?php echo e($tgt->mutu); ?>" oninput="angka(this);" required>	
			            </td>
			            <td>
			            	<input type="text" class="span1" name="waktu[]" 
			            	value="<?php echo e($tgt->waktu); ?>" oninput="angka(this);" required>	
			            </td>
			            <td width="7%">
			            	<select style="width:100%;" name="waktu_id[]" required>	
			            		<option value="">--pilih--</option>
			            		<?php $__currentLoopData = $waktu_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $waktu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($waktu->id); ?>" <?php if($tgt->waktu_id == $waktu->id): ?> selected <?php endif; ?>>
										<?php echo e($waktu->nama); ?>

									</option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
			            </td>
			            <td>
			            	<input type="text" class="span1" name="biaya[]" 
			            	value="<?php echo e($tgt->biaya); ?>" oninput="angka(this);">			
			            </td>			                       
			        </tr>
			        <input type="hidden" name="target_id[]" value="<?php echo e($tgt->id); ?>">
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        			    
		    </tbody>
		    <tfoot>
		    	<tr>
		    		<td colspan="9" style="text-align: center;">		    			
		    			<button type="submit" class=" btn btn-primary">
		    				<i class="icon-save"></i> Simpan
		    			</button>						
		    		</td>
		    	</tr>
		    </tfoot>
		    <?php elseif($status == 'yes' && $jangka->id != 1): ?>		    
		    	<?php echo $__env->make('skp.target_list2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    <?php else: ?>		    	
		    	<tr>
		    		<?php $__currentLoopData = $tgt_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    			<?php if($jangka->id == 3): ?>
			    			<?php
			    				$h_kuan 	= $tgt->kuantitas - $tgt_2[$key]->r_kuantitas;
			    				if ($h_kuan < 0 ) {
			    					$kuantitas = 0;
			    				}else{
			    					$kuantitas = $h_kuan;
			    				}
		   						$waktu 		= $tgt->waktu - $tgt_2[$key]->r_waktu;
			    			?>		    			
		   					<input type="hidden" name="kuantitas[]" value="<?php echo e($kuantitas); ?>">
		   					<input type="hidden" name="waktu[]" value="<?php echo e($waktu); ?>">	
	   					<?php else: ?>
	   						<input type="hidden" name="kuantitas[]" value="">	
	   						<input type="hidden" name="waktu[]" value="">	
	   					<?php endif; ?>	   					
	   					<input type="hidden" name="ak[]" value="">	   					
	   					<input type="hidden" name="output_id[]" value="<?php echo e($tgt->output_id); ?>">
	   					<input type="hidden" name="mutu[]" value="">	   					
	   					<input type="hidden" name="waktu_id[]" value="<?php echo e($tgt->waktu_id); ?>">
	   					<input type="hidden" name="biaya[]" value="">
	   					<input type="hidden" name="target_id[]" value="<?php echo e($tgt_list[$key]->id); ?>">	
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    		<td colspan="9" style="text-align: center;">		    			
		    			<button type="submit" class=" btn btn-primary">
		    				<i class="icon-refresh"></i>&nbsp; Refresh dan Tampilkan Data
		    			</button>						
		    		</td>
		    	</tr>		    
		    <?php endif; ?>
		    </form>	
		</table>
	</div>	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
 	<script type="text/javascript">
 		function angka(that){
 			that.value = that.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
 		}
 	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>