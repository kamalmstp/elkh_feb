<!DOCTYPE html>
<html>
<head>
	<title>PDF LKH</title>
	<style type="text/css">
		body{
			font-family: Times New Roman;
			font-size: 12px;
		}

		thead{
			font-weight: bold;
			text-align: center;
		}
		.border td{
			border: 1px solid;
		}
		.center{
			text-align: center;
		}
		.lebar{
			width: 100%;
		}

		.ttd td{
			padding: 0;
			margin: 0;
		}
		.putih{
			color: white;
		}
	</style>
</head>
<body>

	<h3 class="center">LAPORAN KERJA HARIAN</h3> <br>	
	
	<table border="0">
		<tr>
			<td>NAMA</td>
			<td>:</td>
			<td><?php echo e($lkh->user->name); ?></td>
		</tr>
		<tr>
			<td>NIP / NIPK</td>
			<td>:</td>
			<td><?php echo e($lkh->user->nip); ?></td>
		</tr>
		<tr>
			<td>JABATAN</td>
			<td>:</td>
			<td><?php echo e($lkh->user->jabatan); ?></td>
		</tr>
		<tr>
			<td>HARI / TANGGAL</td>
			<td>:</td>
			<td><?php echo e($dayList[$hari]); ?> / <?php echo e($tanggal); ?></td>
		</tr>
	</table><br>

	<table border="1" cellspacing="0" class="lebar border">
		<thead>
			<tr>
				<td rowspan="2">No.</td>
				<td rowspan="2">Uraian Kegiatan</td>
				<td colspan="2">Waktu</td>
				<td>Keterangan Hasil Kerja</td>
			</tr>
			<tr>
				<td>Mulai</td>
				<td>Selesai</td>
				<td>(Kualitas/Kuantitas)</td>
			</tr>
		</thead>
		<tbody>
			<?php $no = 0; ?>
		    <?php $__currentLoopData = $kegiatan_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <?php $no++; ?>
		        <tr>
		        	<td class="center"><?php echo e($no); ?></td>
		            <td><?php echo e($kegiatan->kegiatan); ?></td>
		            <td class="center"><?php echo e($kegiatan->waktua); ?></td>
	            	<td class="center"><?php echo e($kegiatan->waktub); ?></td>
		            <td class="center"><?php echo e($kegiatan->keterangan); ?></td>
		        </tr>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table><br>

	<table class="ttd" style="float: left; margin-left: 5em; page-break-inside: avoid;">
		<tr>
			<td>Mengetahui</td>			
		</tr>
		<tr>
			<td>Atasan Langsung</td>
		</tr>
		<tr >
			<td style="line-height: 6em;" class="putih">A</td>
		</tr>
		<tr>
			<td><?php echo e($lkh->user->atasan->name); ?></td>
		</tr>
		<tr>
			<td>NIP. <?php echo e($lkh->user->atasan->nip); ?></td>
		</tr>
	</table>
	

	<table border="0" style="float: right; margin-right: 5em; page-break-inside: avoid;">
		<tr>
			<td>Banjarmasin, <?php echo e($tgl_ttd); ?> <?php echo e($blnList[$bln_ttd]); ?> <?php echo e($thn_ttd); ?></td>			
		</tr>
		<tr>
			<td><?php echo e($lkh->user->jabatan); ?></td>
		</tr>
		<tr >
			<td style="line-height: 6em;" class="putih">A</td>
		</tr>
		<tr>
			<td><?php echo e($lkh->user->name); ?> </td>
		</tr>
		<tr>
			<td>NIP. <?php echo e($lkh->user->nip); ?></td>
		</tr>
	</table><br>

</body>
</html>