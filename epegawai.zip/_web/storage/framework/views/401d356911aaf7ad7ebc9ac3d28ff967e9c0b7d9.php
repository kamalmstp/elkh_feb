<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('bawahan_list')); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-table"></i> Sasaran Kerja Pegawai (SKP)		
	</h2>
	<h3>
		<i class="icon-user"></i>
		<?php if(count($skp_list) > 0): ?>
		<?php echo e($skp_list[0]->user->name); ?> - <?php echo e($skp_list[0]->user->jabatan); ?>

		<?php endif; ?>
	</h3>
	<hr>


	<div class="table-responsive">
		<table class="table table-bordered table-small" width="100%" cellspacing="0">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Tahun</th>
		            <th>Opsi</th>
		        </tr>
		    </thead>
		    <tbody>
		    	<?php if(count($skp_list) > 0): ?>
			    	<?php $no = 1; ?>
				    <?php $__currentLoopData = $skp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <tr>
				        	<td><?php echo e($no++); ?></td>
				            <td><?php echo e($skp->tahun->tahun); ?></td>
				            <td>
		            			<a href="<?php echo e(route('targetb_jangka', $skp->id)); ?>" class="btn btn-success " title="Lihat Target Kegiatan SKP"><i class=" icon-screenshot"></i> Target</a>

		            			<a href="<?php echo e(route('realisasib_jangka', $skp->id)); ?>" class="btn btn-warning" title="Lihat Realisasi & Penilaian SKP"><i class=" icon-tasks"></i> Realisasi & Penilaian Kerja</a>	
				            </td>	            
				        </tr>
			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
			    <?php else: ?>
			    	<tr>
			    		<td style="text-align: center;" colspan="3">
			    			<h3>Tidak ada data yang ditampilkan</h3>
			    		</td>
			    	</tr>
			    <?php endif; ?>
		    </tbody>
		</table>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>