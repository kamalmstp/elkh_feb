<tbody>		    	
	<?php $no = 0; ?>
    <?php $__currentLoopData = $tgt_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <?php 
	    	$no++; 
	    	$kuantitas 	= $tgt->kuantitas - $tgt_2[$key]->r_kuantitas;
	   		$waktu 		= $tgt->waktu - $tgt_2[$key]->r_waktu;
	   		
	    ?>
        <tr>
        	<td><?php echo e($no); ?></td>
            <td><?php echo e($tgt->skpkegiatan->kegiatan->kegiatan); ?></td>
            <td>
            	<input type="number" class="span1" name="ak[]" 
            	value="<?php echo e($tgt->ak); ?>" disabled>
            </td>
            <td>
            	<input type="number" class="span1" name="kuantitas[]" 
            	value="<?php echo e($kuantitas); ?>" disabled>
            </td>
            <td>
            	<input type="text" class="span1" value="" disabled>			
            </td>
            <td>
            	<input type="number" class="span1" name="mutu[]" 
            	value="<?php echo e($tgt->mutu); ?>" disabled>	
            </td>
            <td>
            	<input type="number" class="span1" name="waktu[]" 
            	value="<?php echo e($waktu); ?>" disabled>				     
            </td>
            <td>
            	<input type="text" class="span1" value="" disabled>
            </td>
            <td>
            	<input type="number" class="span1" value="<?php echo e($tgt->biaya); ?>">
            </td>			                       
        </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        			    
</tbody>