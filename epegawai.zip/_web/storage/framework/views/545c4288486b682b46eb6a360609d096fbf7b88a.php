<!DOCTYPE html>
<html>
<head>
	<title>PDF LKH</title>
	<style type="text/css">
		body{
			font-family: Times New Roman;
			font-size: 12px;
		}

		thead{
			font-weight: bold;
			text-align: center;
		}
		.border td{
			border: 1px solid;
		}
		.center{
			text-align: center;
		}
		.lebar{
			width: 100%;
		}

		.ttd td{
			padding: 0;
			margin: 0;
		}
		.putih{
			color: white;
		}
	</style>
</head>
<body>

	<h3 class="center">REKAP LAPORAN KERJA HARIAN</h3> <br>	
	
	<table border="0">
		<tr>
			<td>NAMA</td>
			<td>:</td>
			<td><?php echo e($lkh_list[0]->user->name); ?></td>
		</tr>
		<tr>
			<td>NIP / NIPK</td>
			<td>:</td>
			<td><?php echo e($lkh_list[0]->user->nip); ?></td>
		</tr>
		<tr>
			<td>JABATAN</td>
			<td>:</td>
			<td><?php echo e($lkh_list[0]->user->jabatan); ?></td>
		</tr>
		<tr>
			<td>BULAN / TAHUN</td>
			<td>:</td>
			<td><?php echo e($blnList[$bulan]); ?> / <?php echo e($tahun); ?></td>
		</tr>
	</table><br>

	<table border="1" cellspacing="0" class="lebar border" style="font-size: 9px;">
		<thead>
			<tr>
				<td rowspan="2">No.</td>
				<td rowspan="2">Hari / Tanggal</td>
				<td rowspan="2">Uraian Kegiatan</td>
				<td colspan="2">Waktu</td>
				<td>Keterangan Hasil Kerja</td>
			</tr>				
			<tr>
				<td>Mulai</td>
				<td>Selesai</td>
				<td>(Kualitas/Kuantitas)</td>
			</tr>			
		</thead>
		<tbody>
			<?php $no = 1; ?>
			    <?php $__currentLoopData = $lkh_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lkh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    	<?php $__currentLoopData = $lkh->kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        <tr>
			        	<td class="center"><?php echo e($no++); ?></td>
			        	<td class="center">
			        		<?php echo e($dayList[date_format(date_create($lkh->tanggal), "N")]); ?> /
			        		<?php echo e(date_format(date_create($lkh->tanggal), "d/m/Y")); ?>

			        	</td>
			            <td><?php echo e($kegiatan->kegiatan); ?></td>
			            <td class="center"><?php echo e($kegiatan->waktua); ?></td>
		            	<td class="center"><?php echo e($kegiatan->waktub); ?></td>
			            <td class="center"><?php echo e($kegiatan->keterangan); ?></td>
			        </tr>
			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table><br>

	<table class="ttd" style="float: left; margin-left: 5em; page-break-inside: avoid;">
		<tr>
			<td>Mengetahui</td>			
		</tr>
		<tr>
			<td>Atasan Langsung</td>
		</tr>
		<tr >
			<td style="line-height: 6em;" class="putih">A</td>
		</tr>
		<tr>
			<td><?php echo e($lkh_list[0]->user->atasan->name); ?></td>
		</tr>
		<tr>
			<td>NIP. <?php echo e($lkh_list[0]->user->atasan->nip); ?></td>
		</tr>
	</table>
	

	<table border="0" style="float: right; margin-right: 5em; page-break-inside: avoid;">
		<tr>
			<td>Banjarmasin, <?php echo e($tgl_ttd); ?> <?php echo e($blnList[$bln_ttd]); ?> <?php echo e($thn_ttd); ?></td>			
		</tr>
		<tr>
			<td><?php echo e($lkh_list[0]->user->jabatan); ?></td>
		</tr>
		<tr >
			<td style="line-height: 6em;" class="putih">A</td>
		</tr>
		<tr>
			<td><?php echo e($lkh_list[0]->user->name); ?> </td>
		</tr>
		<tr>
			<td>NIP. <?php echo e($lkh_list[0]->user->nip); ?></td>
		</tr>
	</table><br>

</body>
</html>