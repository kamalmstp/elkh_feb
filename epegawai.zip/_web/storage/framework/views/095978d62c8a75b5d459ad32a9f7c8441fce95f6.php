<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="utf-8">
  <title>Dashboard - Bootstrap Admin Template</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="apple-mobile-web-app-capable" content="yes">

  <?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-responsive.min.css')); ?>" rel="stylesheet">    
    <link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
            rel="stylesheet">
  <?php echo $__env->yieldSection(); ?>
</head>

<body>

<?php echo $__env->make('_layout.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">        

        <?php echo $__env->yieldContent('content'); ?>
        
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; 2018 <a href="#">Fakultas Ekonomi dan Bisnis ULM</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 

<!-- Le javascript
================================================== --> 
<?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('js/jquery-1.7.2.min.js')); ?>"></script> 
  <script src="<?php echo e(asset('js/excanvas.min.js')); ?>"></script> 
  <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script> 
  <script src="<?php echo e(asset('js/base.js')); ?>"></script> 
<?php echo $__env->yieldSection(); ?>

</body>
</html>
