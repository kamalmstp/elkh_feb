<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('realisasi_list', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	
	<h2>
		<i class="icon-briefcase"></i> Tugas Tambahan dan Kreativitas / Unsur Penunjang 		
		&ensp;&emsp;
		<button data-toggle="modal" data-target="#inputModal" class="btn btn-primary">
			<i class="icon-plus"></i>  Tambah Tugas Baru
		</button>
		<?php echo $__env->make('skp.tambahan_add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	</h2>
	<h3>
		<i class="icon-calendar"></i> SKP <?php echo e($skp->tahun->tahun); ?> Jangka Waktu <?php echo e($jangka->jangka); ?>

	</h3>
	<hr>

	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<div class="table-responsive">
		<table class="table table-bordered table-small" width="100%" cellspacing="0">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Tugas Tambahan dan Kreativitas / Unsur Penunjang</th>
		            <th>Opsi</th>		            
		        </tr>
		    </thead>
		    <?php if(count($tambahan_list) > 0): ?>
		    <tbody>
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $tambahan_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tambahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php 
				    	$no++;				    	
				     ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($tambahan->tugas); ?></td>			            
			            <td class="btn-group" >
			            	<button data-toggle="modal" data-target="#editModal_<?php echo e($no); ?>" class="btn btn-info" title="Edit Tugas Tambahan"><i class="icon-edit"></i> Edit
							</button>
							<?php echo $__env->make('skp.tambahan_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							<form method="POST" action="<?php echo e(route('tambahan_delete', $tambahan->id)); ?>">
		                    	<input name="_method" type="hidden" value="DELETE">
		                      	<input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
		                      	<button type="submit" class="btn btn-danger "  title="Hapus data satuan" onclick="return confirm('Anda yakin akan menghapus data Tugas Tambahan?')">
		                          	<i class="icon-trash"></i> Hapus
		                      	</button>
		                    </form> 
			            </td>
			        </tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
		    </tbody>
		    <?php else: ?>
		    <tbody>
		    	<tr><td colspan="3" style="text-align: center;">
		    		<h3>Data Tugas Tambahan belum ditambahkan.</h3>
		    	</td></tr>
		    </tbody>
		    <?php endif; ?>
		</table>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>