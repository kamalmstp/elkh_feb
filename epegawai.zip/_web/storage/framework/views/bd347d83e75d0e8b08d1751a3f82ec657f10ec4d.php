<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('realisasib_jangka', $skp->id)); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-tasks"></i> 
		Realisasi SKP <?php echo e($skp->tahun->tahun); ?> Jangka Waktu <?php echo e($jangka->jangka); ?>


		<a href="<?php echo e(route('realisasi_pdf', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" class="btn btn-info">
			<i class="icon-print"></i> Download PDF
		</a>
	</h2>
	<h3>
		<i class="icon-user"></i>
		<?php echo e($skp->user->name); ?> - <?php echo e($skp->user->jabatan); ?>

	</h3>	
	<hr>

	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<div class="table-responsive">
		<table class="table table-bordered table-small">
		    <thead>
		        <tr>
		        	<th rowspan="2">No.</th>
		            <th rowspan="2">Kegiatan</th>		            
		            <th colspan="7">Target</th>
		            <th colspan="7">Realisasi</th>
		            <th rowspan="2">Perhitungan</th>
		            <th rowspan="2">Nilai SKP</th>		            
		        </tr>
		        <tr>
		            <th>AK</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Kuantitas</th>
		            <th>Mutu</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Waktu</th>
		            <th>Biaya</th>
		            <th>AK</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Kuantitas</th>
		            <th>Mutu</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Waktu</th>
		            <th>Biaya</th>
		        </tr>
		    </thead>		    
		    <tbody>
		    	<?php if(count($tgt_list) > 0): ?>
			    	<?php $no = 1; ?>
				    <?php $__currentLoopData = $tgt_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <tr>
				        	<td><?php echo e($no++); ?></td>
				            <td><?php echo e($tgt->skpkegiatan->kegiatan->kegiatan); ?></td>  
				            <td><?php echo e($tgt->ak); ?></td>
				            <td><?php echo e($tgt->kuantitas); ?></td>
				            <td><?php echo e($tgt->output->nama); ?></td>
				            <td><?php echo e($tgt->mutu); ?></td>
				            <td><?php echo e($tgt->waktu); ?></td>
				            <td><?php echo e($tgt->swaktu->nama); ?></td>
				            <td><?php echo e($tgt->biaya); ?></td>
				            <td><?php echo e($tgt->r_ak); ?></td>
				            <td><?php echo e($tgt->r_kuantitas); ?></td>
				            <td><?php echo e($tgt->output->nama); ?></td>
				            <td><?php echo e($tgt->r_mutu); ?></td>
				            <td><?php echo e($tgt->r_waktu); ?></td>
				            <td><?php echo e($tgt->swaktu->nama); ?></td>
				            <td><?php echo e($tgt->r_biaya); ?>	</td>			            
				            <td><?php echo e($tgt->perhitungan); ?></td>
				            <td><?php echo e($tgt->capaian); ?></td>
				        </tr>			        
			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
			    <?php else: ?>
			    	<tr>
			    		<td style="text-align: center;" colspan="18">
			    			<h3>Tidak ada data yang ditampilkan</h3>
			    		</td>
			    	</tr>
			    <?php endif; ?>
		    </tbody>
		</table>		
	</div>
	<hr>

	<h2>
		<i class="icon-briefcase"></i> Tugas Tambahan dan Kreativitas / Unsur Penunjang 				
	</h2><br>

	<div class="table-responsive">
		<table class="table table-bordered table-small" width="100%" cellspacing="0">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Tugas Tambahan dan Kreativitas / Unsur Penunjang</th>		
		        </tr>
		    </thead>
		    <?php if(count($tambahan_list) > 0): ?>
		    <tbody>
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $tambahan_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tambahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php 
				    	$no++;				    	
				     ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($tambahan->tugas); ?></td>			            
			        </tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
		    </tbody>
		    <?php else: ?>
		    <tbody>
		    	<tr><td colspan="2" style="text-align: center;">
		    		<h3>Data Tugas Tambahan belum ditambahkan.</h3>
		    	</td></tr>
		    </tbody>
		    <?php endif; ?>
		</table>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>