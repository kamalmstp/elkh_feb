<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Perilaku extends Model
{
    protected $table = 'perilaku';

	protected $fillable = ['nama'];

}
