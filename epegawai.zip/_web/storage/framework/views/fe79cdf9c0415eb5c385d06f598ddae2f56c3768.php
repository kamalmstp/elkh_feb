<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
    <link href="<?php echo e(asset('css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/daterangepicker.css')); ?>" rel="stylesheet" type="text/css" media="all"  />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2>
		<i class="icon-list"></i> Daftar Laporan Kerja Harian (LKH)
		&ensp;&emsp;
		<button data-toggle="modal" data-target="#inputModal" class="btn btn-primary">
			<i class="icon-plus"></i>  Tambah LKH  Baru
		</button>
		<?php echo $__env->make('lkh.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<button data-toggle="modal" data-target="#inputModal2" class="btn btn-default">
			<i class="icon-file"></i>  Rekap LKH 1 Bulan
		</button>
		<?php echo $__env->make('lkh.rekap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</h2>
	<hr>

	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-danger" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<div class="table-responsive">
		<table class="table table-bordered table-small" id="dataTable" width="100%" cellspacing="0">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Hari/Tanggal</th>
		            <th>Opsi</th>
		        </tr>
		    </thead>
		    <tbody>
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $list_lkh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lkh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php 
				    	$no++;
				    	$tanggal = date_format(date_create($lkh->tanggal), "d/m/Y");
				    	$hari = date_format(date_create($lkh->tanggal), "N");
				     ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($dayList[$hari]); ?> <?php echo e($tanggal); ?> </td>
			            <td class="btn-group">
	            			<a href="<?php echo e(route('lkh_detail', $lkh->id)); ?>" class="btn btn-success " title="Lihat/Tambah Kegiatan"><i class="icon-plus"></i> Kegiatan</a>

	            			<button data-toggle="modal" data-target="#editModal_<?php echo e($no); ?>" class="btn btn-info" title="Edit LKH"><i class="icon-edit"></i> Edit
							</button>
							<?php echo $__env->make('lkh.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	            			
	            			<form method="POST" action="<?php echo e(route('lkh_delete', $lkh->id)); ?>">
		                    	<?php echo e(csrf_field()); ?>

		                    	<input name="_method" type="hidden" value="DELETE">
		                      	<button type="submit" class="btn btn-danger "  title="Hapus LKH" onclick="return confirm('Anda yakin akan menghapus data LKH?')">
		                          	<i class="icon-trash"></i> Hapus
		                      	</button>
		                    </form>  
			            </td>	            
			        </tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
		    </tbody>
		</table>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
	<script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
	<script src="<?php echo e(asset('js/dataTables.bootstrap4.js')); ?>"></script>
	<script src="<?php echo e(asset('js/sb-admin-datatables.min.js')); ?>"></script>  
	<script src="<?php echo e(asset('js/moment.js')); ?>"></script>
	<script src="<?php echo e(asset('js/daterangepicker.js')); ?>"></script> 
	<script src="<?php echo e(asset('js/format_angka.js')); ?>"></script> 
	
	<script type="text/javascript">
    $(function() {
        $('input[name="tanggal"]').daterangepicker({
          singleDatePicker: true,
          showDropdowns: true,
          locale: {
            format: 'DD-MM-YYYY'
          }
        });
    });
  </script>	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>