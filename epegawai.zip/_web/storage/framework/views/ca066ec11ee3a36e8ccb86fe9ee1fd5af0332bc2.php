<!DOCTYPE html>
<html>
<head>
	<title>PDF Realisasi SKP</title>
	<style type="text/css">
		body{
			font-family: Arial Narrow;
			font-size: 8px;
		}

		thead{
			font-weight: bold;
			text-align: center;
		}
		.border td{
			border: 1px solid;
		}
		.center{
			text-align: center;
		}
		.lebar{
			width: 100%;
		}

		.ttd td{
			padding: 0;
			margin: 0;
		}
		.putih{
			color: white;
		}
		.kanan{
			text-align: right;
		}
	</style>
</head>
<body>

	<h3 class="center">
		PENILAIAN CAPAIAN SASARAN KERJA <br>
		PEGAWAI NEGERI SIPIL	
	</h3> 

	<p>
		Jangka Waktu Penilaian <?php echo e($tgl_start); ?> <?php echo e($blnList[$bln_start]); ?> s.d. <?php echo e($tgl_end); ?> <?php echo e($blnList[$bln_end]); ?> <?php echo e($thn_end); ?>

	</p>
	
	<table border="1" cellspacing="0" class="lebar border">
		<thead>
			<tr>
				<th rowspan="2">NO.</th>
				<th rowspan="2" >III. KEGIATAN TUGAS JABATAN</th>
				<th rowspan="2">AK</th>
				<th colspan="6" class="center">TARGET</th>
				<th rowspan="2">AK</th>
				<th colspan="6" class="center">REALISASI</th>
				<th rowspan="2">PERHITUNGAN</th>
				<th rowspan="2">NILAI CAPAIAN SKP</th>
			</tr>
			<tr class="center">
				<th colspan="2">KUANT/OUTPUT</th>
				<th>KUAL/MUTU</th>
				<th colspan="2">WAKTU</th>
				<th>BIAYA</th>
				<th colspan="2">KUANT/OUTPUT</th>
				<th>KUAL/MUTU</th>
				<th colspan="2">WAKTU</th>
				<th>BIAYA</th>
				
			</tr>
		</thead>
		<tbody>
			<?php $no = 0; ?>
		    <?php $__currentLoopData = $tgt_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <?php $no++; ?>	
				<tr>
					<td class="center"><?php echo e($no); ?></td>
					<td ><?php echo e($tgt->skpkegiatan->kegiatan->kegiatan); ?></td>
					<td class="center"><?php echo e($tgt->ak); ?></td>
					<td class="center"><?php echo e($tgt->kuantitas); ?></td>
					<td class="center"><?php echo e($tgt->output->nama); ?></td>
					<td class="center"><?php echo e($tgt->mutu); ?></td>
					<td class="center"><?php echo e($tgt->waktu); ?></td>
					<td class="center"><?php echo e($tgt->swaktu->nama); ?></td>
					<td class="center"><?php echo e($tgt->biaya); ?></td>
					<td class="center"><?php echo e($tgt->r_ak); ?></td>
					<td class="center"><?php echo e($tgt->r_kuantitas); ?></td>
					<td class="center"><?php echo e($tgt->output->nama); ?></td>
					<td class="center"><?php echo e($tgt->r_mutu); ?></td>
					<td class="center"><?php echo e($tgt->r_waktu); ?></td>
					<td class="center"><?php echo e($tgt->swaktu->nama); ?></td>
					<td class="center"><?php echo e($tgt->r_biaya); ?></td>	
					<td class="center"><?php echo e($tgt->perhitungan); ?></td>	
					<td class="kanan">
						<?php echo e(number_format((float)$tgt->capaian, 2, '.', '')); ?>

					</td>	
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<th></th>
				<th style="text-align: left;">II. TUGAS TAMBAHAN DAN KREATIVITAS/UNSUR PENUNJANG :</th>
				<th></th>
				<th colspan="6"></th>
				<th></th>
				<th colspan="6"></th>
				<th></th>
				<th></th>
			</tr>
			<tr>
				<td></td><td></td><td></td>
				<td colspan="6"></td><td></td>
				<td colspan="6"></td><td></td>
				<td rowspan="<?php echo e(count($tambahan_list)+1); ?>" class="center">
					<?php echo e($n_tambahan); ?>

				</td>
			</tr>
			<?php $no2 = 0; ?>
		    <?php $__currentLoopData = $tambahan_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tambahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <?php $no2++; ?>	
				<tr>
					<td class="center"><?php echo e($no2); ?></td>
					<td><?php echo e($tambahan->tugas); ?></td>
					<td></td>
					<td colspan="6"></td>
					<td></td>
					<td colspan="6"></td>
					<td></td>
				</tr>				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

			<tr>
				<td></td><td></td><td></td>
				<td colspan="6">&nbsp;</td><td></td>
				<td colspan="6"></td><td></td>
				<td ></td>
			</tr>
			<tr>
				<td rowspan="2" colspan="17" class="center">Nilai Capaian SKP</td>
				<td class="kanan"><?php echo e(number_format((float)$nilai_capaian, 2, '.', '')); ?></td>
			</tr>
			<tr>
				<td class="center">(<?php echo e($kat); ?>)</td>
			</tr>
		</tbody>
	</table><br>	

	<table class="ttd" style="float: right; margin-right: 5em; page-break-inside: avoid;">
		<tr>
			<td>Banjarmasin,  <?php echo e($tgl_ttd); ?> <?php echo e($blnList[$bln_ttd]); ?> <?php echo e($thn_ttd); ?></td>
		</tr>
		<tr>
			<td>Pejabat Penilai,</td>
		</tr>
		<tr>
			<td style="line-height: 6em;" class="putih">A</td>
		</tr>
		<tr>
			<td><?php echo e($skp->user->atasan->name); ?></td>
		</tr>
		<tr>
			<td>NIP. <?php echo e($skp->user->atasan->nip); ?></td>
		</tr>
	</table>	


</body>
</html>