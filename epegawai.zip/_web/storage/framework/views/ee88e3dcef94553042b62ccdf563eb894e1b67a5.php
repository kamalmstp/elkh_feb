<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('skp_list')); ?>" class="btn btn-success">
		<i class="icon-arrow-left"></i> Kembali
	</a><hr>

	<?php if(Session::has('gagal')): ?>
	  <div class="alert alert-danger" role="alert"><?php echo e(Session::get('gagal')); ?></div>
	<?php endif; ?>

	<h2>
		<i class="icon-tasks"></i> Realisasi SKP Tahun: <?php echo e($skp->tahun->tahun); ?>

	</h2>
		
	<?php $__currentLoopData = $jangka_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jangka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e(route('realisasi_list', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" class="btn btn-warning btn-large" title="Lihat/Input Target">
			Realisasi <?php echo e($jangka->jangka); ?>

		</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<hr>

	<h2>
		<i class="icon-star"></i> Penilaian Perilaku Kerja Tahun: <?php echo e($skp->tahun->tahun); ?>

	</h2>
		
	<?php $__currentLoopData = $jangka_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jangka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e(route('penilaian_list', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" class="btn btn-info btn-large" title="Lihat/Input Target">
			Penilaian <?php echo e($jangka->jangka); ?>

		</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	


	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>