<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2>
		<i class="icon-key"></i> Ganti Password		
	</h2>
	<hr>

    <?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>
	<?php if(Session::has('gagal')): ?>
	  <div class="alert alert-danger" role="alert"><?php echo e(Session::get('gagal')); ?></div>
	<?php endif; ?>

    <?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-danger" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<form method="POST" action="<?php echo e(route('password_save')); ?>" enctype="multipart/form-data">
    	<?php echo e(csrf_field()); ?>		
		
		<div class="row">
			
			<div class="span4">											
				<label class="control-label">Password Baru</label>
				<div class="controls">
					<input type="password" class="span4" name="password" required autofocus>
				</div> 
			</div> 
			<div class="span4">											
				<label class="control-label">Konfirmasi Password</label>
				<div class="controls">
					<input type="password" class="span4" name="password_confirmation" required>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="span6">
				<button type="submit" class="btn btn-primary">
					<i class="icon-save"></i> Simpan
				</button>
			</div>
		</div>
	</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>