<?php
return [
    'previous' => '&laquo; Sebelumnya',
    'next'     => 'Berikutnya &raquo;',
];
