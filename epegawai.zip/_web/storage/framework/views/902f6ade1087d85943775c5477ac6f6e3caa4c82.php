<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
    <link href="<?php echo e(asset('css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('lkhb_list', $lkh->user->id)); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-list"></i> Detail LKH  		
	</h2>
	<h3>
		<i class="icon-user"></i>
		<?php echo e($user->name); ?> - <?php echo e($user->jabatan); ?>

	</h3>
	<h4>
		<i class="icon-calendar"></i> Hari/Tanggal: <?php echo e($dayList[$hari]); ?> <?php echo e($tanggal); ?>

		&ensp;&emsp;		
		
		<button data-toggle="modal" data-target="#pdfModal" class="btn btn-default" title="LKH PDF">
			<i class="icon-file"></i>  Download PDF
		</button>
		<?php echo $__env->make('lkh.rekap1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</h4>

	<div class="table-responsive">
		<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Uraian Kegiatan</th>
		            <th>Waktu</th>
		            <th>Keterangan</th>		            
		        </tr>
		    </thead>
		    <tbody>
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $kegiatan_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php $no++; ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($kegiatan->kegiatan); ?></td>
			            <td><?php echo e($kegiatan->waktua); ?> - <?php echo e($kegiatan->waktub); ?></td>
			            <td><?php echo e($kegiatan->keterangan); ?></td>			                
			        </tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
		    </tbody>
		</table>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
  <script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(asset('js/dataTables.bootstrap4.js')); ?>"></script>
  <script src="<?php echo e(asset('js/sb-admin-datatables.min.js')); ?>"></script>  
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>