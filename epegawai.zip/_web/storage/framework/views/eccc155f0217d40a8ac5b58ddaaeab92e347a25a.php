<html>
	<head>		
		<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
		<style>
			body {
				margin: 0;
				padding: 0;
				width: 100%;
				height: 100%;
				color: black;
				display: table;
				font-weight: 100;
				font-family:'sans-serif';
			}

			.container {
				text-align: center;
				display: table-cell;
				vertical-align: middle;
			}

			.content {
				text-align: center;
				display: inline-block;
			}

			.title {
				font-size: 2em;
				margin-bottom: 40px;
				font-weight: bold;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<div class="content">
				<div class="title">Anda Tidak Memiliki Hak Akses Ke Halaman Ini</div>
			</div>
		</div>
	</body>
</html>
