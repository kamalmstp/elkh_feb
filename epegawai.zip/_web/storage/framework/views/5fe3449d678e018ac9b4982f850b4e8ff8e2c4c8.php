<!DOCTYPE html>
<html>
<head>
	<title>PDF Target SKP</title>
	<style type="text/css">
		body{
			font-family: Arial Narrow, Arial;
			font-size: 11px;
		}

		thead{
			font-weight: bold;
			text-align: center;
		}
		.border td{
			border: 1px solid;
		}
		.center{
			text-align: center;
		}
		.lebar{
			width: 100%;
		}

		.ttd td{
			padding: 0;
			margin: 0;
		}
		.putih{
			color: white;
		}
	</style>
</head>
<body>

	<h3 class="center">
		FORMULIR SASARAN KERJA <br>
		PEGAWAI NEGERI SIPIL	
	</h3> 
	
	<table border="1" cellspacing="0" class="lebar border">
		<thead>
			<tr>
				<th>NO.</th>
				<th colspan="2">I. PEJABAT PENILAI</th>
				<th>NO.</th>
				<th colspan="6">II. PEGAWAI NEGERI SIPIL YANG DINILAI</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="center">1<br> 2<br>3<br>4<br>5</td>
				<td>Nama <br> NIP <br> Pangkat/Gol.Ruang <br> Jabatan <br> Unit Kerja</td>
				<td>
					<?php echo e($skp->user->atasan->name); ?> <br>
					<?php echo e($skp->user->atasan->nip); ?>	<br>
					<?php echo e($skp->user->atasan->pangkat->pangkat); ?>	/ <?php echo e($skp->user->atasan->pangkat->golongan); ?> <br>
					<?php echo e($skp->user->atasan->jabatan); ?> <br>
					Fakultas Ekonomi dan Bisnis Unlam <br>
				</td>
				<td class="center">1<br>2<br>3<br>4<br>5</td>
				<td colspan="2">Nama <br> NIP <br> Pangkat/Gol.Ruang <br> Jabatan <br> Unit Kerja</td>
				<td colspan="4">
					<?php echo e($skp->user->name); ?> <br>
					<?php echo e($skp->user->nip); ?> <br>
					<?php echo e($skp->user->pangkat->pangkat); ?> / <?php echo e($skp->user->pangkat->golongan); ?>  	 <br>
					<?php echo e($skp->user->jabatan); ?>  <br>
					Fakultas Ekonomi dan Bisnis Unlam <br>
				</td>
			</tr>
			<tr class="center">
				<th rowspan="2">NO.</th>
				<th rowspan="2" colspan="2">III. KEGIATAN TUGAS JABATAN</th>
				<th rowspan="2">AK</th>
				<th colspan="6" class="center">TARGET</th>
			</tr>
			<tr class="center">
				<th colspan="2">KUANT/OUTPUT</th>
				<th>KUAL/MUTU</th>
				<th colspan="2">WAKTU</th>
				<th>BIAYA</th>
			</tr>

			<?php $no = 0; ?>
		    <?php $__currentLoopData = $tgt_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <?php $no++; ?>	
				<tr>
					<td class="center"><?php echo e($no); ?></td>
					<td colspan="2"><?php echo e($tgt->skpkegiatan->kegiatan->kegiatan); ?></td>
					<td class="center"><?php echo e($tgt->ak); ?></td>
					<td class="center"><?php echo e($tgt->kuantitas); ?></td>
					<td class="center"><?php echo e($tgt->output->nama); ?></td>
					<td class="center"><?php echo e($tgt->mutu); ?></td>
					<td class="center"><?php echo e($tgt->waktu); ?></td>
					<td class="center"><?php echo e($tgt->swaktu->nama); ?></td>
					<td class="center"><?php echo e($tgt->biaya); ?></td>	
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table><br>	

	<table class="ttd" style="float: left; margin-left: 5em;">
		<tr>
			<td class="putih">A</td>
		</tr>
		<tr>
			<td>Pejabat Penilai,</td>
		</tr>
		<tr>
			<td style="line-height: 6em;" class="putih">A</td>
		</tr>
		<tr>
			<td><?php echo e($skp->user->atasan->name); ?></td>
		</tr>
		<tr>
			<td>NIP. <?php echo e($skp->user->atasan->nip); ?></td>
		</tr>
	</table>	

	<table border="0" style="float: right; margin-right: 5em; page-break-inside: avoid;">
		<tr>
			<td>Banjarmasin, <?php echo e($tgl_ttd); ?> <?php echo e($blnList[$bln_ttd]); ?> <?php echo e($thn_ttd); ?></td>			
		</tr>
		<tr>
			<td>Pegawai Negeri Sipil Yang Dinilai</td>
		</tr>
		<tr >
			<td style="line-height: 6em;" class="putih">A</td>
		</tr>
		<tr>
			<td><?php echo e($skp->user->name); ?> </td>
		</tr>
		<tr>
			<td>NIP. <?php echo e($skp->user->nip); ?></td>
		</tr>
	</table><br>

</body>
</html>