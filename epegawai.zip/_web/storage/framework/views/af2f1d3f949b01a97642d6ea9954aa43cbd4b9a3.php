<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('skp_list')); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-screenshot"></i> Target SKP
	</h2>
	<h4>
		<i class="icon-calendar"></i> Tahun: 
			<?php echo e($skp->tahun->tahun); ?>	
        	&ensp;&emsp;
		<button data-toggle="modal" data-target="#inputModal" class="btn btn-primary">
			<i class="icon-plus"></i>  Tambah Kegiatan Baru
		</button>
		<?php echo $__env->make('skp.target_add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</h4>
	<hr>

	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<div class="table-responsive" style="overflow-x: auto;">
		<table class="table table-bordered table-small">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Kegiatan</th>
		            <th>AK</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Kuantitas</th>
		            <th>Mutu</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Waktu</th>
		            <th>Biaya</th>
		            <th>Opsi</th>
		        </tr>
		    </thead>
		    <tbody>
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $target_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php $no++; ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($tgt->kegiatan->kegiatan); ?></td>
			            <td><?php echo e($tgt->ak); ?></td>
			            <td><?php echo e($tgt->kuantitas); ?></td>
			            <td><?php echo e($tgt->output->nama); ?></td>
			            <td><?php echo e($tgt->mutu); ?></td>
			            <td><?php echo e($tgt->waktu); ?></td>
			            <td><?php echo e($tgt->swaktu->nama); ?></td>
			            <td><?php echo e($tgt->biaya); ?></td>
			            <td>
			            	<table border="0">
			            	<tr>			            		
			            		<td>		            			
			            			<button data-toggle="modal" data-target="#editModal_<?php echo e($no); ?>" class="btn btn-info btn-small" title="Edit SKP"><i class="icon-edit"></i>
									</button>
									<?php echo $__env->make('skp.target_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            		</td>
			            		<td>
			            			<form method="POST" action="<?php echo e(route('target_delete', $tgt->id)); ?>">
				                    	<input name="_method" type="hidden" value="DELETE">
				                      	<input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
				                      	<button type="submit" class="btn btn-small btn-danger "  title="Hapus data satuan" onclick="return confirm('Anda yakin akan menghapus data Target?')">
				                          	<i class="icon-trash"></i>
				                      	</button>
				                    </form>    		
			            		</td>
			            	</tr>
			            	</table>		            		
			            </td>	            
			        </tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
		    </tbody>
		</table>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>