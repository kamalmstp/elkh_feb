<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
   <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('user_list')); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-user"></i> Edit User
	</h2>
	<hr>
	
	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<form method="POST" action="<?php echo e(route('user_update', $user->id)); ?>" enctype="multipart/form-data">
    	<?php echo e(csrf_field()); ?>		
    	<input type="hidden" name="_method" value="PATCH">
		<div class="row">
			<div class="span6">											
				<label class="control-label">Nama</label>
				<div class="controls">
					<input type="text" class="span6" name="name" value="<?php echo e($user->name); ?>" required autofocus>
				</div> 
			</div> 
			<div class="span6">											
				<label class="control-label">NIP</label>
				<div class="controls">
					<input type="text" class="span6" name="nip" value="<?php echo e($user->nip); ?>" required>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="span6">											
				<label class="control-label">Pangkat/Golongan Ruang</label>
				<div class="controls">
					<select class="span6" name="pangkat_id" required>						
						<?php $__currentLoopData = $pkt_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($pkt->id); ?>" <?php if($user->pangkat->id == $pkt->id): ?>			selected <?php endif; ?>>
								<?php echo e($pkt->pangkat); ?> / <?php echo e($pkt->golongan); ?>

							</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
				</div>
			</div>
			<div class="span6">											
				<label class="control-label">Bagian</label>
				<div class="controls">
					<select class="span6" name="bagian_id" required>						
						<?php $__currentLoopData = $bgn_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($bgn->id); ?>" <?php if($user->bagian->id == $bgn->id): ?>			selected <?php endif; ?>>
								<?php echo e($bgn->bagian); ?>

							</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
				</div>
			</div>
		</div>

		<div class="row">
			<div class="span4">											
				<label class="control-label">Jabatan</label>
				<div class="controls">
					<input type="text" class="span4" name="jabatan" value="<?php echo e($user->jabatan); ?>" required>
				</div> 
			</div> 
			<div class="span4">											
				<label class="control-label">Atasan</label>
				<div class="controls">
					<select class="js-example-placeholder-single span4" name="atasan_id" required>
						<?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($atasan->id); ?>" <?php if($user->atasan->id == $atasan->id): ?>			selected <?php endif; ?>>
							<?php echo e($atasan->name); ?>

						</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					
				</div>
			</div> 
			<div class="span4">											
				<label class="control-label">Email</label>
				<div class="controls">
					<input type="email" class="span4" name="email" value="<?php echo e($user->email); ?>" required>
				</div> 
			</div> 
		</div>

		<div class="row">
			<div class="span6">
				<input type="button" class="btn btn-warning" onClick="show()" value="Ganti Password">
			</div>
		</div><br>

		<div class="row" id="password" style="display: none;">
			<div class="span6">											
				<label class="control-label">Password Baru</label>
				<div class="controls">
					<input type="password" class="span6" name="password">
				</div> 
			</div> 
			<div class="span6">											
				<label class="control-label">Konfirmasi Password</label>
				<div class="controls">
					<input type="password" class="span6" name="password_confirmation">
				</div>
			</div>
		</div>

		<div class="row">
			<div class="span6">
				<button type="submit" class="btn btn-primary">
					<i class="icon-save"></i> Simpan Perubahan
				</button>
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

  <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script> 
  <script type="text/javascript">
	$(document).ready(function() {
	    $('.js-example-placeholder-single').select2({
	    	placeholder: "Pilih Atasan",
	    	allowClear: true
	    });
	});
  </script>
  
  <script type="text/javascript">
    function show(){
      
      document.getElementById('password').style.display="block" ;
    }
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>