<div id="inputModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="inputModalLabel" aria-hidden="true">
		<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="inputModalLabel">Tambah Kegiatan SKP Baru</h3>
 	</div>
	<form action="<?php echo e(route('skpkegiatan_save', $skp->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

	  	<div class="modal-body">
		  	<div class="row">				
				<div class="span6">											
					<label class="control-label">Kegiatan</label>
					<div class="controls">
						<select class="js-example-placeholder-single span5" name="kegiatan_id" required autofocus>							
	                        <option></option>	                        
							<?php $__currentLoopData = $keg_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($keg->id); ?>"><?php echo e($keg->kegiatan); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>					
					</div>
				</div>
			</div>
		</div>
	  	<div class="modal-footer">
	    	<button class="btn" data-dismiss="modal" aria-hidden="true">Batal</button>
	    	<button type="submit" class="btn btn-primary">Tambah</button>
	  	</div>
  	</form>
</div>