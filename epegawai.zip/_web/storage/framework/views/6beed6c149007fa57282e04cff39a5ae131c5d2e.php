<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('realisasi_jangka', $skp->id)); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-tasks"></i> 
		Realisasi SKP <?php echo e($skp->tahun->tahun); ?> Jangka Waktu <?php echo e($jangka->jangka); ?>


		<button data-toggle="modal" data-target="#pdfModal" class="btn btn-default">
			<i class="icon-file"></i> Download PDF
		</button>
		<?php echo $__env->make('skp.realisasi_pdf_tgl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</h2>	
	<hr>

	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<div class="table-responsive">
		<form action="<?php echo e(route('realisasi_update', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" method="POST" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>		    				    	
			<input type="hidden" name="_method" value="PATCH">	
		<table class="table table-bordered table-small">
		    <thead>
		        <tr>
		        	<th rowspan="2">No.</th>
		            <th rowspan="2">Kegiatan</th>		            
		            <th colspan="7">Target</th>
		            <th colspan="7">Realisasi</th>
		            <th rowspan="2">Perhitungan</th>
		            <th rowspan="2">Nilai SKP</th>		            
		        </tr>
		        <tr>
		            <th>AK</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Kuantitas</th>
		            <th>Mutu</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Waktu</th>
		            <th>Biaya</th>

		            <th>AK</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Kuantitas</th>
		            <th>Mutu</th>
		            <th colspan="2" class="sorting" tabindex="0" aria-controls="dataTable">Waktu</th>
		            <th>Biaya</th>
		            
		        </tr>
		    </thead>		    
		    <?php if($status == 'yes'): ?> 	
		    <tbody>
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $tgt_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php $no++; ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($tgt->skpkegiatan->kegiatan->kegiatan); ?></td>		            
			            <td><?php echo e($tgt->ak); ?></td>
			            <td><?php echo e($tgt->kuantitas); ?></td>
			            <td><?php echo e($tgt->output->nama); ?></td>
			            <td><?php echo e($tgt->mutu); ?></td>
			            <td><?php echo e($tgt->waktu); ?></td>
			            <td><?php echo e($tgt->swaktu->nama); ?></td>
			            <td><?php echo e($tgt->biaya); ?></td>

			            <td>
			            	<input type="text" class="span1" name="r_ak[]" 
			            	value="<?php echo e($tgt->r_ak); ?>" oninput="angka(this);">
			            </td>
			            <td>
			            	<input type="text" class="span1" name="r_kuantitas[]" 
			            	value="<?php echo e($tgt->r_kuantitas); ?>" oninput="angka(this);" required>
			            </td>
			            <td>
			            	<input type="text" class="span1" value="<?php echo e($tgt->output->nama); ?>" disabled>
			            </td>
			             <td>
			            	<input type="text" class="span1" name="r_mutu[]" 
			            	value="<?php echo e($tgt->r_mutu); ?>" oninput="angka(this);" required>	
			            </td>
			            <td>
			            	<input type="text" class="span1" name="r_waktu[]" 
			            	value="<?php echo e($tgt->r_waktu); ?>" oninput="angka(this);" required>				     
			            </td>
			            <td>
			            	<input type="text" class="span1" value="<?php echo e($tgt->swaktu->nama); ?>" disabled>			            	
			            </td>
			            <td>
			            	<input type="text" class="span1" name="r_biaya[]" 
			            	value="<?php echo e($tgt->r_biaya); ?>" oninput="angka(this);">	
			            </td>			            
			            <td>
			            	<?php echo e($tgt->perhitungan); ?>

			            </td>
			            <td>
			            	<?php echo e($tgt->capaian); ?>

			            </td>
			        </tr>
			        <input type="hidden" name="target_id[]" value="<?php echo e($tgt->id); ?>">
			        <input type="hidden" name="t_kuantitas[]" value="<?php echo e($tgt->kuantitas); ?>">
			        <input type="hidden" name="t_mutu[]" value="<?php echo e($tgt->mutu); ?>">
			        <input type="hidden" name="t_waktu[]" value="<?php echo e($tgt->waktu); ?>">
			        <input type="hidden" name="t_biaya[]" value="<?php echo e($tgt->biaya); ?>">
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
		    </tbody>
	      	<tfoot>
		    	<tr>
		    		<td colspan="18" style="text-align: center;">		    			
		    			<button type="submit" class=" btn btn-primary">
		    				<i class="icon-save"></i> Simpan
		    			</button>						
		    		</td>
		    	</tr>
		    </tfoot>		    
			<?php else: ?>
				<tr>
		    		<?php $__currentLoopData = $tgt_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    			<?php
		    				$kuantitas 	= $tgt->r_kuantitas + $tgt_3[$key]->r_kuantitas;
	   						$waktu 		= $tgt->r_waktu + $tgt_3[$key]->r_waktu;
		    			?>		    			
	   					<input type="hidden" name="r_kuantitas[]" value="<?php echo e($kuantitas); ?>">
	   					<input type="hidden" name="r_waktu[]" value="<?php echo e($waktu); ?>">	
	   					<input type="hidden" name="r_ak[]" value="">	   					
	   					<input type="hidden" name="r_mutu[]" value="">	   					
	   					<input type="hidden" name="r_biaya[]" value="">
	   					<input type="hidden" name="t_kuantitas[]" value="<?php echo e($tgt_list[$key]->kuantitas); ?>">
				        <input type="hidden" name="t_mutu[]" value="<?php echo e($tgt_list[$key]->mutu); ?>">
				        <input type="hidden" name="t_waktu[]" value="<?php echo e($tgt_list[$key]->waktu); ?>">
				        <input type="hidden" name="t_biaya[]" value="<?php echo e($tgt_list[$key]->biaya); ?>">
	   					<input type="hidden" name="target_id[]" value="<?php echo e($tgt_list[$key]->id); ?>">	
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    		<td colspan="18" style="text-align: center;">		    			
		    			<button type="submit" class=" btn btn-primary">
		    				<i class="icon-refresh"></i>&nbsp; Refresh dan Tampilkan Data
		    			</button>						
		    		</td>
		    	</tr>
			<?php endif; ?>

		    </form>	
		</table>		
	</div>
	<hr>

	<h2>
		<i class="icon-briefcase"></i> Tugas Tambahan dan Kreativitas / Unsur Penunjang 		
		&ensp;&emsp;
		<?php if($jangka->id != 1): ?>
			<a href="<?php echo e(route('tambahan_list', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" class="btn btn-primary">
				<i class="icon-wrench"></i>  Kelola Tugas Tambahan 
			</a>		
		<?php endif; ?>
	</h2><br>

	<div class="table-responsive">
		<table class="table table-bordered table-small" width="100%" cellspacing="0">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Tugas Tambahan dan Kreativitas / Unsur Penunjang</th>		            
		        </tr>
		    </thead>
		    <?php if(count($tambahan_list) > 0): ?>
		    <tbody>
		    	<?php $no = 0; ?>
			    <?php $__currentLoopData = $tambahan_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tambahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php 
				    	$no++;				    	
				     ?>
			        <tr>
			        	<td><?php echo e($no); ?></td>
			            <td><?php echo e($tambahan->tugas); ?></td>			            
			        </tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
		    </tbody>
		    <?php else: ?>
		    <tbody>
		    	<tr><td colspan="2" style="text-align: center;">
		    		<h3>Data Tugas Tambahan belum ditambahkan.</h3>
		    	</td></tr>
		    </tbody>
		    <?php endif; ?>
		</table>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
 	<script type="text/javascript">
 		function angka(that){
 			that.value = that.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
 		}
 	</script>	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>