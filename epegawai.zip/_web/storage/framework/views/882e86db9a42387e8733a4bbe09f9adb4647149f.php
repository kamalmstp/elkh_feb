<tbody>		    	
	<?php $no = 0; ?>
    <?php $__currentLoopData = $tgt_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tgt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <?php $no++; ?>
        <tr>
        	<td><?php echo e($no); ?></td>
            <td><?php echo e($tgt->skpkegiatan->kegiatan->kegiatan); ?></td>
            <td>
            	<input type="text" class="span1" name="ak[]" value="<?php echo e($tgt->ak); ?>" oninput="angka(this);">
            </td>
            <td>
            	<input type="text" class="span1" name="kuantitas[]" value="<?php echo e($tgt->kuantitas); ?>" oninput="angka(this);" required>
            </td>
            <td>
            	<input type="text" class="span1" value="<?php echo e($tgt->output->nama); ?>" disabled>			
            </td>
            <td>
            	<input type="text" class="span1" name="mutu[]" value="<?php echo e($tgt->mutu); ?>" oninput="angka(this);" required>	
            </td>
            <td>
            	<input type="text" class="span1" name="waktu[]" value="<?php echo e($tgt->waktu); ?>" required>
            </td>
            <td>
            	<input type="text" class="span1" value="<?php echo e($tgt->swaktu->nama); ?>" disabled>	
            </td>
            <td>
            	<input type="text" class="span1" name="biaya[]" value="<?php echo e($tgt->biaya); ?>" oninput="angka(this);">
            </td>			                       
        </tr>        
        <input type="hidden" name="output_id[]" value="<?php echo e($tgt->output_id); ?>">
        <input type="hidden" name="waktu_id[]" value="<?php echo e($tgt->waktu_id); ?>">
        <input type="hidden" name="target_id[]" value="<?php echo e($tgt_list[$key]->id); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        			    
</tbody>
<tfoot>
	<tr>
		<td colspan="9" style="text-align: center;">		    			
			<button type="submit" class=" btn btn-primary">
				<i class="icon-save"></i> Simpan
			</button>						
		</td>
	</tr>
</tfoot>