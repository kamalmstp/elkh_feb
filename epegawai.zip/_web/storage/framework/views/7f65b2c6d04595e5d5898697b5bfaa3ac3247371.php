<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('realisasib_jangka', $skp->id)); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	
	<h2>
		<i class="icon-star"></i> Penilaian Perilaku Kerja 				
	</h2>
	<h3>
		<i class="icon-calendar"></i> Tahun <?php echo e($skp->tahun->tahun); ?> Jangka Waktu <?php echo e($jangka->jangka); ?>

	</h3>
	<h3>
		<i class="icon-user"></i>
		<?php echo e($skp->user->name); ?> - <?php echo e($skp->user->jabatan); ?>

		&ensp;&emsp;
		<?php if(count($penilaian_list) != 0): ?>
			<button data-toggle="modal" data-target="#pdfModal" class="btn btn-default">
				<i class="icon-file"></i> Download PDF
			</button>
			<?php echo $__env->make('skp.penilaian_pdf_tgl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endif; ?>
	</h3>


	<hr>

	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>

	<?php if(Session::has('gagal')): ?>
	  <div class="alert alert-danger" role="alert"><?php echo e(Session::get('gagal')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<?php if(count($penilaian_list) != 0): ?>
	<form action="<?php echo e(route('penilaianb_status', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" method="POST" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>		    				    	
		<input type="hidden" name="_method" value="PATCH">	
		<?php if($penilaian_list[0]->status == 1): ?>
			<input type="hidden" name="status" value="0">
			<button type="submit" class="btn btn-primary" style="margin-bottom: 1em;" title="Tutup penilaian untuk bawahan?">
				<i class="icon-key"></i> Penilaian dibuka
			</button>
		<?php else: ?>
			<input type="hidden" name="status" value="1">
			<button type="submit" class="btn btn-warning" style="margin-bottom: 1em;" title="Buka penilaian untuk bawahan?">
				<i class="icon-key"></i> Penilaian ditutup
			</button>
		<?php endif; ?>
	</form>
	<?php endif; ?>

	<table border="1" cellpadding="5" width="45%" style="float: left;">
	    <thead>
	        <tr>
	        	<th>Perilaku Kerja</th>
	            <th>Nilai Angka</th>
	            <th>Kategori</th>
	        </tr>
	    </thead>
	    <?php if(count($penilaian_list) != 0): ?>
	    <tbody>
	    	<form action="<?php echo e(route('penilaian_update', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" method="POST" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>		    				    	
			<input type="hidden" name="_method" value="PATCH">
			<input type="hidden" name="form" value="penilaian">
	    	<?php $__currentLoopData = $penilaian_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<tr>
	    		<td><?php echo e($penilaian->perilaku->nama); ?></td>
	    		<td style="text-align: center;">	    			
	    			<input type="text" class="span1" name="nilai[]" value="<?php echo e($penilaian->nilai); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
	    			<input type="hidden" name="penilaian_id[]" value="<?php echo e($penilaian->id); ?>">
	    		</td>
	    		<td>
	    			<?php echo e($penilaian->kategori->nama); ?>

	    		</td>
	    	</tr>
	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </tbody>
	    <tfoot>
	    	<tr>
	    		<td colspan="3" style="text-align: center;">
	    				<button type="submit" class=" btn btn-primary">
							<i class="icon-save"></i> Simpan
						</button>	    					    		
					</form>		
					<form></form>
					<?php else: ?>						
	    				<tfoot>
	    				<tr><td colspan="3" style="text-align: center;">
		    			<button class="btn btn-primary" onclick="window.location.reload()">
	    					<i class="icon-refresh"></i> Refresh dan Input Nilai
	    				</button>
					<?php endif; ?>
	    		</td>
	    	</tr>	    	
	    </tfoot>
	</table>

	<?php if(count($penilaian_list) != 0): ?>
		
		<form action="<?php echo e(route('penilaian_update', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" method="POST" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>		    				    	
				<input type="hidden" name="_method" value="PATCH">
				<input type="hidden" name="form" value="riwayat">
			<div style="float: right;">
				<select class="span2" name="rwtahun_id" required>
					<option value="">-- Tahun --</option>
					<?php $__currentLoopData = $thn_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($thn->id); ?>"><?php echo e($thn->tahun); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				<select class="span2" name="rwjangka_id" required>
					<option value="">-- Semester --</option>
					<?php $__currentLoopData = $jangka_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jangka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($jangka->id); ?>"><?php echo e($jangka->jangka); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				<input class="btn btn-primary btn-small" type="submit" value="Tampilkan Riwayat Penilaian">
				
			</div><br><br>
		</form>
		<?php if($rw_penilaian != ''): ?>
		<table border="1" cellpadding="5" width="45%" style="float: right;">
		    <thead>
		    	<tr>
		    		<th colspan="3">
		    			Riwayat Penilaian Tahun <?php echo e($rw_skp->tahun->tahun); ?> 
		    			<?php echo e($rw_jangka->jangka); ?>

		    		</th>
		    	</tr>
		        <tr>
		        	<th>Perilaku Kerja</th>
		            <th>Nilai Angka</th>
		            <th>Kategori</th>
		        </tr>
		    </thead>
		    <tbody>		    	
		    	<?php if(count($rw_penilaian) == 0): ?>
					<tr>
						<th colspan="3">Tidak ada Riwayat Penilaian</th>
					</tr>
				<?php else: ?>
					<?php $__currentLoopData = $rw_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    	<tr>
			    		<td><?php echo e($penilaian2->perilaku->nama); ?></td>
			    		<td style="text-align: center;">
			    			<?php echo e($penilaian2->nilai); ?>

			    		</td>
			    		<td>
			    			<?php echo e($penilaian2->kategori->nama); ?>

			    		</td>
			    	</tr>
			    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
		    </tbody>
		</table>
		<?php endif; ?>
	<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>