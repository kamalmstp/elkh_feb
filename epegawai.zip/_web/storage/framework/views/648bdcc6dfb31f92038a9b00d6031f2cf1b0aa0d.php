<?php $__env->startSection('css'); ?>
    ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##   
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('skp_list')); ?>" class="btn btn-success"><i class="icon-arrow-left"></i> Kembali</a>
	<h2>
		<i class="icon-table"></i> Kegiatan SKP Tahun <?php echo e($skp->tahun->tahun); ?>

		&ensp;&emsp;
		
	</h2>
	<br>

	<?php if( count($skpkeg_list) > 0 ): ?>		
		<?php $__currentLoopData = $jangka_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jangka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="<?php echo e(route('target_list', ['id'=>$skp->id, 'jangka_id'=>$jangka->id])); ?>" class="btn btn-warning" title="Lihat/Input Target" style="font-weight: bold;">
				Target <?php echo e($jangka->jangka); ?>

			</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
	<?php endif; ?>
	
	<hr>
	<?php if(Session::has('sukses')): ?>
	  <div class="alert alert-success" role="alert"><?php echo e(Session::get('sukses')); ?></div>
	<?php endif; ?>

	<?php if(Session::has('gagal')): ?>
	  <div class="alert alert-danger" role="alert"><?php echo e(Session::get('gagal')); ?></div>
	<?php endif; ?>

	<?php if($errors): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="alert alert-warning" role="alert"> <?php echo e($error); ?></div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<button data-toggle="modal" data-target="#inputModal" class="btn btn-primary">
		<i class="icon-plus"></i>  Tambah Kegiatan Baru
	</button>
	<?php echo $__env->make('skp.kegiatan_add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<br><br>
	
	<div class="table-responsive">
		<table class="table table-bordered table-small" width="100%" cellspacing="0">
		    <thead>
		        <tr>
		        	<th>No.</th>
		            <th>Kegiatan</th>
		            <th>Opsi</th>
		        </tr>
		    </thead>
		    <tbody>
		    	<?php if(count($skpkeg_list) > 0): ?>
			    	<?php $no = 1; ?>
				    <?php $__currentLoopData = $skpkeg_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skpkeg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <tr>
				        	<td><?php echo e($no++); ?></td>
				            <td><?php echo e($skpkeg->kegiatan->kegiatan); ?></td>
				            <td class="btn-group" style="width: 15%;">
		            			<button data-toggle="modal" data-target="#editModal_<?php echo e($no); ?>" class="btn btn-info" title="Edit Kegiatan SKP"><i class="icon-edit"></i>
								</button>
								<?php echo $__env->make('skp.kegiatan_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		            			<form method="POST" action="<?php echo e(route('skpkegiatan_delete', $skpkeg->id)); ?>">
			                    	<input name="_method" type="hidden" value="DELETE">
			                      	<input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
			                      	<button type="submit" class="btn btn-danger "  title="Hapus data satuan" onclick="return confirm('Anda yakin akan menghapus data kegiatan SKP?')">
			                          	<i class="icon-trash"></i>
			                      	</button>
			                    </form>    		
				            </td>	            
				        </tr>
			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	        
			    <?php else: ?>
			    	<tr>
			    		<td style="text-align: center;" colspan="3">
			    			<h3>Tidak ada data yang ditampilkan</h3>
			    		</td>
			    	</tr>
			    <?php endif; ?>
		    </tbody>
		</table>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##	
 	<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script> 
	<script type="text/javascript">
	$(document).ready(function() {
	    $('.js-example-placeholder-single').select2({
	    	placeholder: "Pilih Kegiatan",
	    	allowClear: true
	    });
	});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>