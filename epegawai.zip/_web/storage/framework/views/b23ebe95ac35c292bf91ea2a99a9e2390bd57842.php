<div id="inputModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="inputModalLabel" aria-hidden="true">
		<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="inputModalLabel">Tambah Terget Kegiatan SKP Baru</h3>
 	</div>
	<form action="<?php echo e(route('target_save', $skp->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

	  	<div class="modal-body">
		  	<div class="row">				
				<div class="span6">											
					<label class="control-label">Kegiatan</label>
					<div class="controls">
						<select class="span6" name="kegiatan_id" required autofocus>							
	                        <option value="">-- pilih --</option>	                        
							<?php $__currentLoopData = $keg_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($keg->id); ?>"><?php echo e($keg->kegiatan); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>					
					</div>
				</div>
				<div class="span6">											
					<label class="control-label">AK</label>
					<div class="controls">
						<input type="number" name="ak" class="span6">
					</div>
				</div>
				<div class="span6">											
					<label class="control-label">Kuantitas</label>
					<div class="controls">
						<input type="number" name="kuantitas" class="span2">
						<select class="span4" name="output_id" required>							
	                        <option value="">-- pilih --</option>	                        
							<?php $__currentLoopData = $output_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $output): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($output->id); ?>"><?php echo e($output->nama); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>									
				</div>
				<div class="span6">											
					<label class="control-label">Mutu</label>
					<div class="controls">
						<input type="number" name="mutu" class="span6">
					</div>
				</div>
				<div class="span6">											
					<label class="control-label">Waktu</label>
					<div class="controls">
						<input type="number" name="waktu" class="span2">
						<select class="span4" name="waktu_id" required>							
	                        <option value="">-- pilih --</option>	                        
							<?php $__currentLoopData = $waktu_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $waktu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($waktu->id); ?>"><?php echo e($waktu->nama); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>									
				</div>
				<div class="span6">											
					<label class="control-label">Biaya</label>
					<div class="controls">
						<input type="number" name="biaya" class="span6">
					</div>
				</div>



			</div>
		</div>
	  	<div class="modal-footer">
	    	<button class="btn" data-dismiss="modal" aria-hidden="true">Batal</button>
	    	<button type="submit" class="btn btn-primary">Tambah</button>
	  	</div>
  	</form>
</div>